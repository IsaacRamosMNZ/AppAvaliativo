package br.ulbra.avaliaao;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private String currentTitle = "Starboy";
    private String currentArtist = "The Weeknd, Daft Punk";
    private int currentArtRes = R.drawable.sample_album_art;
    private boolean isMiniPlaying = true;

    private TextView miniTvTitle;
    private TextView miniTvArtist;
    private ImageView miniIvArt;
    private ImageView miniBtnPlayPause;

    private TextView[] chips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initViews();
        setupSongClickListeners();
        setupChipListeners();
        setupMiniPlayerListeners();
        setupNavigationListeners();
    }

    private void initViews() {
        miniTvTitle = findViewById(R.id.miniTvTitle);
        miniTvArtist = findViewById(R.id.miniTvArtist);
        miniIvArt = findViewById(R.id.miniIvArt);
        miniBtnPlayPause = findViewById(R.id.miniBtnPlayPause);

        chips = new TextView[]{
                findViewById(R.id.chip1),
                findViewById(R.id.chip2),
                findViewById(R.id.chip3),
                findViewById(R.id.chip4),
                findViewById(R.id.chip5)
        };
    }

    private void openPlayerScreen(String title, String artist, int artRes) {
        currentTitle = title;
        currentArtist = artist;
        currentArtRes = artRes;

        miniTvTitle.setText(currentTitle);
        miniTvArtist.setText(currentArtist);
        miniIvArt.setImageResource(currentArtRes);

        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(PlayerActivity.EXTRA_SONG_TITLE, title);
        intent.putExtra(PlayerActivity.EXTRA_SONG_ARTIST, artist);
        intent.putExtra(PlayerActivity.EXTRA_ART_RES_ID, artRes);
        startActivity(intent);
    }

    private void setupSongClickListeners() {
        // Album Card 1 & Quick Pick 1
        View.OnClickListener listenerSong1 = v ->
                openPlayerScreen("Starboy", "The Weeknd, Daft Punk", R.drawable.sample_album_art);
        findViewById(R.id.cardSong1).setOnClickListener(listenerSong1);
        findViewById(R.id.itemQuickPick1).setOnClickListener(listenerSong1);

        // Album Card 2 & Quick Pick 2
        View.OnClickListener listenerSong2 = v ->
                openPlayerScreen("Blinding Lights", "The Weeknd", R.drawable.sample_album_art_2);
        findViewById(R.id.cardSong2).setOnClickListener(listenerSong2);
        findViewById(R.id.itemQuickPick2).setOnClickListener(listenerSong2);

        // Album Card 3 & Quick Pick 3
        View.OnClickListener listenerSong3 = v ->
                openPlayerScreen("Die With A Smile", "Lady Gaga, Bruno Mars", R.drawable.sample_album_art_3);
        findViewById(R.id.cardSong3).setOnClickListener(listenerSong3);
        findViewById(R.id.itemQuickPick3).setOnClickListener(listenerSong3);
    }

    private void setupChipListeners() {
        for (int i = 0; i < chips.length; i++) {
            final int index = i;
            chips[i].setOnClickListener(v -> selectChip(index));
        }
    }

    private void selectChip(int selectedIndex) {
        for (int i = 0; i < chips.length; i++) {
            if (i == selectedIndex) {
                chips[i].setBackgroundResource(R.drawable.bg_chip_selected);
                chips[i].setTextColor(ContextCompat.getColor(this, R.color.black));
            } else {
                chips[i].setBackgroundResource(R.drawable.bg_chip);
                chips[i].setTextColor(ContextCompat.getColor(this, R.color.yt_text_primary));
            }
        }
        Toast.makeText(this, "Filtro: " + chips[selectedIndex].getText(), Toast.LENGTH_SHORT).show();
    }

    private void setupMiniPlayerListeners() {
        // Clicking mini player opens Full Player
        findViewById(R.id.miniPlayer).setOnClickListener(v ->
                openPlayerScreen(currentTitle, currentArtist, currentArtRes));

        // Mini player Play/Pause
        miniBtnPlayPause.setOnClickListener(v -> {
            isMiniPlaying = !isMiniPlaying;
            if (isMiniPlaying) {
                miniBtnPlayPause.setImageResource(R.drawable.ic_pause);
                Toast.makeText(this, "Reproduzindo", Toast.LENGTH_SHORT).show();
            } else {
                miniBtnPlayPause.setImageResource(R.drawable.ic_play_arrow);
                Toast.makeText(this, "Pausado", Toast.LENGTH_SHORT).show();
            }
        });

        // Mini player Next
        findViewById(R.id.miniBtnNext).setOnClickListener(v -> {
            openPlayerScreen("Blinding Lights", "The Weeknd", R.drawable.sample_album_art_2);
            Toast.makeText(this, "Próxima faixa", Toast.LENGTH_SHORT).show();
        });
    }

    private void setupNavigationListeners() {
        LinearLayout navHome = findViewById(R.id.navBtnHome);
        LinearLayout navExplore = findViewById(R.id.navBtnExplore);
        LinearLayout navLibrary = findViewById(R.id.navBtnLibrary);

        navHome.setOnClickListener(v ->
                Toast.makeText(this, "Página Início", Toast.LENGTH_SHORT).show());

        navExplore.setOnClickListener(v ->
                Toast.makeText(this, "Navegando para Explorar", Toast.LENGTH_SHORT).show());

        navLibrary.setOnClickListener(v ->
                Toast.makeText(this, "Navegando para Biblioteca", Toast.LENGTH_SHORT).show());

        findViewById(R.id.btnSearch).setOnClickListener(v ->
                Toast.makeText(this, "Abrir pesquisa", Toast.LENGTH_SHORT).show());

        findViewById(R.id.btnProfile).setOnClickListener(v ->
                Toast.makeText(this, "Conta do usuário", Toast.LENGTH_SHORT).show());

        findViewById(R.id.btnCast).setOnClickListener(v ->
                Toast.makeText(this, "Transmitir dispositivo", Toast.LENGTH_SHORT).show());
    }
}