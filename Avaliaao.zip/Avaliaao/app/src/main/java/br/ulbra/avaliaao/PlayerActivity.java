package br.ulbra.avaliaao;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class PlayerActivity extends AppCompatActivity {

    public static final String EXTRA_SONG_TITLE = "extra_song_title";
    public static final String EXTRA_SONG_ARTIST = "extra_song_artist";
    public static final String EXTRA_ART_RES_ID = "extra_art_res_id";

    private boolean isPlaying = true;
    private boolean isLiked = false;
    private boolean isDisliked = false;
    private boolean isShuffleOn = false;
    private boolean isRepeatOn = false;

    private ImageView ivPlayPauseIcon;
    private ImageView btnLike;
    private ImageView btnDislike;
    private ImageView btnShuffle;
    private ImageView btnRepeat;
    private TextView tvSongTitle;
    private TextView tvArtistName;
    private ImageView ivAlbumArt;
    private SeekBar seekBarProgress;
    private TextView tvCurrentTime;
    private TextView tabSong;
    private TextView tabVideo;
    private TextView tabUpNext;
    private TextView tabLyrics;
    private TextView tabRelated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_player);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initViews();
        loadIntentData();
        setupListeners();
    }

    private void initViews() {
        ivPlayPauseIcon = findViewById(R.id.ivPlayPauseIcon);
        btnLike = findViewById(R.id.btnLike);
        btnDislike = findViewById(R.id.btnDislike);
        btnShuffle = findViewById(R.id.btnShuffle);
        btnRepeat = findViewById(R.id.btnRepeat);
        tvSongTitle = findViewById(R.id.tvSongTitle);
        tvArtistName = findViewById(R.id.tvArtistName);
        ivAlbumArt = findViewById(R.id.ivAlbumArt);
        seekBarProgress = findViewById(R.id.seekBarProgress);
        tvCurrentTime = findViewById(R.id.tvCurrentTime);

        tabSong = findViewById(R.id.tabSong);
        tabVideo = findViewById(R.id.tabVideo);

        tabUpNext = findViewById(R.id.tabUpNext);
        tabLyrics = findViewById(R.id.tabLyrics);
        tabRelated = findViewById(R.id.tabRelated);
    }

    private void loadIntentData() {
        String title = getIntent().getStringExtra(EXTRA_SONG_TITLE);
        String artist = getIntent().getStringExtra(EXTRA_SONG_ARTIST);
        int artRes = getIntent().getIntExtra(EXTRA_ART_RES_ID, R.drawable.sample_album_art);

        if (title != null) tvSongTitle.setText(title);
        if (artist != null) tvArtistName.setText(artist);
        ivAlbumArt.setImageResource(artRes);
    }

    private void setupListeners() {
        // Collapse arrow finishes activity to go back to Home
        findViewById(R.id.btnCollapse).setOnClickListener(v -> finish());

        // Play/Pause toggle
        findViewById(R.id.btnPlayPause).setOnClickListener(v -> {
            isPlaying = !isPlaying;
            if (isPlaying) {
                ivPlayPauseIcon.setImageResource(R.drawable.ic_pause);
                Toast.makeText(this, "Reproduzindo", Toast.LENGTH_SHORT).show();
            } else {
                ivPlayPauseIcon.setImageResource(R.drawable.ic_play_arrow);
                Toast.makeText(this, "Pausado", Toast.LENGTH_SHORT).show();
            }
        });

        // Like toggle
        btnLike.setOnClickListener(v -> {
            isLiked = !isLiked;
            if (isLiked) {
                isDisliked = false;
                btnLike.setImageTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                btnDislike.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.yt_icon_tint)));
                Toast.makeText(this, "Adicionado às músicas curtidas", Toast.LENGTH_SHORT).show();
            } else {
                btnLike.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.yt_icon_tint)));
            }
        });

        // Dislike toggle
        btnDislike.setOnClickListener(v -> {
            isDisliked = !isDisliked;
            if (isDisliked) {
                isLiked = false;
                btnDislike.setImageTintList(ColorStateList.valueOf(Color.parseColor("#3EA6FF")));
                btnLike.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.yt_icon_tint)));
                Toast.makeText(this, "Marcado como Não Gostei", Toast.LENGTH_SHORT).show();
            } else {
                btnDislike.setImageTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.yt_icon_tint)));
            }
        });

        // Shuffle toggle
        btnShuffle.setOnClickListener(v -> {
            isShuffleOn = !isShuffleOn;
            int color = isShuffleOn ? ContextCompat.getColor(this, R.color.yt_icon_tint)
                    : ContextCompat.getColor(this, R.color.yt_icon_disabled);
            btnShuffle.setImageTintList(ColorStateList.valueOf(color));
            Toast.makeText(this, isShuffleOn ? "Modo aleatório ativado" : "Modo aleatório desativado", Toast.LENGTH_SHORT).show();
        });

        // Repeat toggle
        btnRepeat.setOnClickListener(v -> {
            isRepeatOn = !isRepeatOn;
            int color = isRepeatOn ? ContextCompat.getColor(this, R.color.yt_red)
                    : ContextCompat.getColor(this, R.color.yt_icon_tint);
            btnRepeat.setImageTintList(ColorStateList.valueOf(color));
            Toast.makeText(this, isRepeatOn ? "Repetir ativado" : "Repetir desativado", Toast.LENGTH_SHORT).show();
        });

        // Previous / Next mock
        findViewById(R.id.btnPrevious).setOnClickListener(v ->
                Toast.makeText(this, "Música anterior", Toast.LENGTH_SHORT).show());
        findViewById(R.id.btnNext).setOnClickListener(v ->
                Toast.makeText(this, "Próxima música", Toast.LENGTH_SHORT).show());

        // Song / Video tabs toggle
        tabSong.setOnClickListener(v -> {
            tabSong.setBackgroundResource(R.drawable.bg_pill_active);
            tabSong.setTextColor(ContextCompat.getColor(this, R.color.yt_text_primary));
            tabVideo.setBackground(null);
            tabVideo.setTextColor(ContextCompat.getColor(this, R.color.yt_text_secondary));
        });

        tabVideo.setOnClickListener(v -> {
            tabVideo.setBackgroundResource(R.drawable.bg_pill_active);
            tabVideo.setTextColor(ContextCompat.getColor(this, R.color.yt_text_primary));
            tabSong.setBackground(null);
            tabSong.setTextColor(ContextCompat.getColor(this, R.color.yt_text_secondary));
            Toast.makeText(this, "Modo Vídeo selecionado", Toast.LENGTH_SHORT).show();
        });

        // Bottom sheet tabs selection
        tabUpNext.setOnClickListener(v -> selectBottomTab(tabUpNext, "Próximas faixas na fila"));
        tabLyrics.setOnClickListener(v -> selectBottomTab(tabLyrics, "Exibindo letras da música"));
        tabRelated.setOnClickListener(v -> selectBottomTab(tabRelated, "Carregando faixas relacionadas"));

        // Seekbar progress listener
        seekBarProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    int totalSeconds = (int) (progress * 2.3); // Scale 0-100 to 0-230s (3:50)
                    int minutes = totalSeconds / 60;
                    int seconds = totalSeconds % 60;
                    tvCurrentTime.setText(String.format(Locale.getDefault(), "%d:%02d", minutes, seconds));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void selectBottomTab(TextView selectedTab, String message) {
        tabUpNext.setTextColor(ContextCompat.getColor(this, R.color.yt_text_secondary));
        tabLyrics.setTextColor(ContextCompat.getColor(this, R.color.yt_text_secondary));
        tabRelated.setTextColor(ContextCompat.getColor(this, R.color.yt_text_secondary));

        selectedTab.setTextColor(ContextCompat.getColor(this, R.color.yt_text_primary));
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}